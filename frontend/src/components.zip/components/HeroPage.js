import React from "react";
import '../styles/hero.css';
import { useNavigate } from "react-router-dom";
import NavBar from "./NavBar";

const HeroPage = () => {
  const navigate = useNavigate(); // Initialize the navigate function using useNavigate

  const handleClick = () => {
      navigate("/UploadPage"); // Use navigate function to navigate to another page
  };
  return (
    <>
    <NavBar/>
    <div className="main-div">
     
      <h1>MindMatrix</h1>
      <div  className='small-text'>
        <p>
          MindMatrix is an innovative solution that leverages LLM (Language,
          Logic, and Mathematics) to create powerful data synergies. By
          integrating these three fundamental principles of human knowledge,
          MindMatrix offers a unique approach to data management and analysis.
        </p>
      </div>
      <button className="button-start" onClick={handleClick} >Get Started</button>
      <div className="info-boxes">
        <div className="info-box">
        
            <h2>Harness the Power of LLM</h2>
            <p>MindMatrix revolutionizes data management by integrating Language, Logic, and Mathematics (LLM) principles to create powerful data synergies.</p>
        </div>
        <div  className="info-box">
            <h2>Context-Aware Preprocessing</h2>
            <p>Our innovative approach integrates Large Language Models (LLMs) to extract crucial context from datasets, ensuring optimal selection of machine learning models for more efficient workflows.</p>
        </div>
        <div  className="info-box">
            <h2>Redefining Benchmarks</h2>
            <p>Join us in ushering in a new era of automated data preprocessing and model selection. With MindMatrix, gain a competitive edge and unlock unparalleled insights from your data.</p>
        </div>

      </div>
    </div></>
  );
};

export default HeroPage;
