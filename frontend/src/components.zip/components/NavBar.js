import React from "react";

function NavBar() {
  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        width: "100%",
        marginbottom: "2rem",
        height: "3rem",
        backgroundColor: "#E4E4E4",
        color: "black",
        textAlign: "center",
        lineHeight: "3rem",
        fontWeight: "bold",
        boxShadow:"0px 0px 4px 2px rgba(0, 0, 0, 0.2)",
      }}
    >
      MINDMATRIX
    </div>
  );
}

export default NavBar;
